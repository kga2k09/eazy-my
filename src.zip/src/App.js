import React, { Component } from 'react';
import './App.css';
import EazyApp from './containers/EazyApp';

class App extends Component {
  render() {
    return (
      <div >
        <EazyApp />
      </div>
    );
  }
}

export default App;
