import React, { Component } from 'react';
import Header from '../../components/header';
import {Container, Row} from 'reactstrap'
class EazyApp extends Component {

    render() {
        return(
       
                    <Header />
    
            
        )
    }
}

export default EazyApp;